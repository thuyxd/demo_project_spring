package com.sd.service;

import com.sd.entity.User;
import com.sd.service.dto.UserDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;


public interface UserService {
    List<User> findAllUser();

    Optional<User> findById(Long id);

    void save(User user);

    public User registerUser(UserDTO userDTO, String password);

    public User createUser(UserDTO userDTO);

    public Optional<UserDTO> updateUser(UserDTO userDTO);

    public void deleteUser(User user);

    public void changePassword(String currentClearTextPassword, String newPassword);

    public Page<UserDTO> getAllManagedUsers(Pageable pageable);

    public Optional<User> getUserWithAuthorities(Long id);

    public List<String> getAuthorities();

    public Optional<User> getUserWithAuthorities();
}
