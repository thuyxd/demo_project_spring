package com.sd.service.dto;

import com.sd.entity.Authority;
import com.sd.entity.User;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import java.util.stream.Collectors;

public class UserDTO {
    private Long id;

    @NotBlank
    @Size(min = 1, max = 50)
    private String email;

    @Size(max = 50)
    private String fullname;

    @Size(max = 256)
    private String imageUrl;

    @Size(max = 256)
    private String address;

    @Size(max = 256)
    private String phone;



    public UserDTO(User user) {
        this.id = user.getId();
        this.email = user.getEmail();
        this.fullname = user.getFullName();
        this.imageUrl = user.getImageUrl();
        this.address = user.getAddress();
        this.phone = user.getPhone();
    }

    public UserDTO() {
    }

    public UserDTO(Long id, @NotBlank @Size(min = 1, max = 50) String email, @Size(max = 50) String fullname, @Size(max = 256) String imageUrl, @Size(max = 256) String address, @Size(max = 256) String phone) {
        this.id = id;
        this.email = email;
        this.fullname = fullname;
        this.imageUrl = imageUrl;
        this.address = address;
        this.phone = phone;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
