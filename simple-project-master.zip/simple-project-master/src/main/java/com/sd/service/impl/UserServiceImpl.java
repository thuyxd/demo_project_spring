package com.sd.service.impl;

import com.sd.config.Constants;
import com.sd.entity.Authority;
import com.sd.entity.User;
import com.sd.repository.UserRepository;
import com.sd.security.AuthoritiesConstants;
import com.sd.security.SecurityUtils;
import com.sd.service.UserService;
import com.sd.service.dto.UserDTO;
import com.sd.util.RandomUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final Logger log = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;


    @Override
    public List<User> findAllUser() {
        return userRepository.findAll();
    }

    @Override
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    public void save(User user) {
        userRepository.save(user);
    }

    @Override
    public User registerUser(UserDTO userDTO, String password) {
        return null;
    }

    @Override
    public User createUser(UserDTO userDTO) {
        return null;
    }

    @Override
    public Optional<UserDTO> updateUser(UserDTO userDTO) {
        return Optional.empty();
    }

    @Override
    public void deleteUser(User user) {
        userRepository.delete(user);
    }

    @Override
    public void changePassword(String currentClearTextPassword, String newPassword) {

    }

    @Override
    public Page<UserDTO> getAllManagedUsers(Pageable pageable) {
        return null;
    }

    @Override
    public Optional<User> getUserWithAuthorities(Long id) {
        return Optional.empty();
    }

    @Override
    public List<String> getAuthorities() {
        return null;
    }

    @Override
    public Optional<User> getUserWithAuthorities() {
        return Optional.empty();
    }
}
