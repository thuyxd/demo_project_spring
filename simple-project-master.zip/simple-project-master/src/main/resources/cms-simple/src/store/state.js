// https://vuex.vuejs.org/en/state.html

export default {
  //
}
