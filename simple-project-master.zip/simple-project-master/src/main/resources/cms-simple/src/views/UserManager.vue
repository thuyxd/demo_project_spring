<template>
    <v-container
            fill-height
            fluid
            grid-list-xl
    >
        <v-layout
                justify-center
                wrap
        >
            <v-flex
                    md12
            >
                <material-card
                        color="green"
                        title="User Table"
                >
                    <v-data-table
                            :headers="headers"
                            :items="items"
                            hide-actions
                    >
                        <template
                                slot="headerCell"
                                slot-scope="{ header }"
                        >
              <span
                      class="subheading font-weight-light text-success text--darken-3"
                      v-text="header.text"
              />
                        </template>
                        <template
                                slot="items"
                                slot-scope="{ item }"
                        >
                            <td>{{ item.name }}</td>
                            <td>{{ item.country }}</td>
                            <td>{{ item.city }}</td>
                            <td>{{ item.salary }}</td>
                            <td>{{ item.salary }}</td>
                            <td>{{ item.salary }}</td>
                        </template>
                    </v-data-table>
                </material-card>
            </v-flex>
        </v-layout>
    </v-container>
</template>

<script >

</script>
