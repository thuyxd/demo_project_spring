import {RoleEnum} from "./RoleEnums";


export class User {
    public id?: String;
    public login: String = '';
    public fullname: String = '';
    public password: String = '';
    public email?: String = '';
    public authorities: RoleEnum;
    public imageUrl?:String='';
}