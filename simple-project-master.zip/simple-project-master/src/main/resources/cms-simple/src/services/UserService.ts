import Vue from '../main';
import {AxiosPromise} from "axios"
import {User} from "../models/User"
import {Response} from "../models/shared/Response"

class UserService extends Vue {
    private ROOT_API = process.env.VUE_APP_ROOT_API +'/api/user';

    public getAll(): AxiosPromise<Response<User>> {
        return Vue.axios.get<Response<User>>(this.ROOT_API+'/');
    }

}
export const userService = new UserService();