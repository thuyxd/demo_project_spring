export class LoginDto {
	public username?: string;
	public password?: string;
	
	constructor(init?: Partial<LoginDto>) {
		Object.assign(this, init);
	}
}