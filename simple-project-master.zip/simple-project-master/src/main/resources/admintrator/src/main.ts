import Vue from 'vue';
import App from './App.vue';
import router from './router';
import store from './store';

import axios from 'axios';
import VueAxios from 'vue-axios';
Vue.use(VueAxios, axios);

Vue.config.productionTip = false;


// @ts-ignore
import BootstrapVue from 'bootstrap-vue';
Vue.use(BootstrapVue);

import moment from 'moment';
Vue.prototype.$moment = moment;

const mainApp = new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount('#app');
export default mainApp;