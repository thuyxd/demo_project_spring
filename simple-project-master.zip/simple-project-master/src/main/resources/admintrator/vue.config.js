module.exports = {
    runtimeCompiler: true
};